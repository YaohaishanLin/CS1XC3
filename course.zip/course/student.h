/**
 * @file student.h
 * @author Yaohaishan Lin
 * @date 2022-04-07
 * @brief Student library for storing student information, including student type definition 
 *        and student functions.
 *
 */


/**
 * Student type stores student information with their first name, last name,
 * id, grades, and number of grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name*/
  char last_name[50]; /**< the student's last name*/
  char id[11]; /**< the 10-digit student id*/
  double *grades; /**< the student's grades*/
  int num_grades; /**< the number of student's grade*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
