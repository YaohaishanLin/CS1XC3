/**
 * @file student.c
 * @author Yaohaishan Lin
 * @brief Student library for storing students' information, including definitions of Student
 *        function.
 * @version 0.1
 * @date 2022-04-07
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief add grades to the student.
 * 
 * @param student a student representing as a struct
 * @param grade 
 * @return nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); //if the total number of grade for a student is 1, allocate one space to 0 for the grade
  else //If it is the other case
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);//reallocate spaces for the rest of grades
  }
  student->grades[student->num_grades - 1] = grade; // Then insert the grade you want to add
}
/**
 * @brief Calculate the average grade of a student's grades. 
 * 
 * @param student a student representing as a struct
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; //Add up all grades
  return total / ((double) student->num_grades);// divide by the number of grades
}
/**
 * @brief prints the student information. Name, ID, grades, and averagee grade.
 * 
 * @param student a student representing as a struct
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief Generate a random student.
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); //First allocate one space to 0 on the heap for student

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);// Randomly select first name and last name from the lists, add to the student

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0'; // Generate random 10-digit student id

  for (int i = 0; i < grades; i++) // Add the same number of grades with the parameter "grades" to the student
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); //grades are randomly generated
  }

  return new_student;
}