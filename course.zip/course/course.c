/**
 * @file course.c
 * @author Yaohaishan Lin
 * @date 2022-04-07
 * @brief Course library for course information, including definitions of Course
 *        function.
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief Add a student to the course.
 * 
 * @param course a course representing as a struct
 * @param student a student representing as a struct
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) //If the total number of srudents in the course is 1
  {
    course->students = calloc(1, sizeof(Student)); //allocate a space to 0 for the student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); //eallocate spaces for the other students
  }
  course->students[course->total_students - 1] = *student; //insert the student you want to add
}
/**
 * @brief Print a course information. The course name, the course code, total number of students,
 * and students' information in a list.
 * 
 * @param course a course representing as a struct
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief Finding the student with the top grade in this course.
 *
 * @param course a course representing as a struct
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; //If the total number of students in the course is 0, then return NULL.
 
  double student_average = 0;
  double max_average = average(&course->students[0]); //Otherwise, set the maximum avergae grade as the first student's grade
  Student *student = &course->students[0]; //set the top student currently as the first student
 
  for (int i = 1; i < course->total_students; i++) //in a for loop, compare the other students' grades with the maximum grade
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) //if the other students' grade is higher than the maximum avergae grade
    {
      max_average = student_average; 
      student = &course->students[i]; // that student's grade becomes the maximum grade, until we reach to the end of students
    }   
  }

  return student;
}
/**
 * @brief Find all students that pass the course.
 * 
 * @param course 
 * @param total_passing 
 * @return list of students pass the coruse as an dynamic array
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) //First count the number of students who are passing the course
    if (average(&course->students[i]) >= 50) count++; //if the student's average grade is over 50, then they passes.
  
  passing = calloc(count, sizeof(Student)); // Then allocated spaces to 0 for those students

  int j = 0;
  for (int i = 0; i < course->total_students; i++) // in a for loop, insert students' information to the dynamic array
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}