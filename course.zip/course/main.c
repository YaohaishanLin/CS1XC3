/**
 * @mainpage Course function demonstration
 * @file main.c
 * @author Yaohaishan Lin 
 * @brief the main funciton demonstration shows how multiple functions in the course library work,
 * including:
 * - enrolling students into te course
 * - printing the course information
 * - fiinding the top student in the course
 * - finding students who pass the course
 *
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/** 
 * Create a course called "MATH101", insert 20 random students,
 * prints the students' information, find the top student, and all the students who pass the course.
 *
 */

int main()
{
  srand((unsigned) time(NULL));

  //allocate a space to 0 for the course, call it MATH101
  Course *MATH101 = calloc(1, sizeof(Course));
  //insert course name
  strcpy(MATH101->name, "Basics of Mathematics");
  //insert course code
  strcpy(MATH101->code, "MATH 101");

  //generate 20 random students and add them to MATH101
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  //print the course information
  print_course(MATH101);

  //Find the top student using the function top_student, and print them
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //find all students who pass the course using the function passing and print them
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}