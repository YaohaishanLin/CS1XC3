/**
 * @file course.h
 * @author Yaohaishan Lin
 * @date 2022-04-07
 * @brief Course library for course information, including course type definition
 *        and course funcitons.
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * Course type stores a course with the course name, the course code,
 * students who are taking this course, and the total number of students who are 
 * taking this coruse.
 * 
 */

typedef struct _course 
{
  char name[100]; /**< the course name*/
  char code[10]; /**< the course code*/
  Student *students; /**< students' information who are taking this course*/
  int total_students; /**< the total number of students who are taking this course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


